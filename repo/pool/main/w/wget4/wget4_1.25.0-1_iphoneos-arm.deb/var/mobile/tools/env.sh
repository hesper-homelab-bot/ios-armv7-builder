# Source this (or add /var/mobile/tools to PATH) to use wget4/curl4.
export PATH=/var/mobile/tools:$PATH
export SSL_CERT_FILE=/etc/ssl/cert.pem
